﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","hu",{button:"Illeszd be a kódtöredéket",codeContents:"Kód tartalom",emptySnippetError:"A kódtöredék nem lehet üres.",language:"Nyelv",title:"Kódtöredék",pathName:"kódtöredék"});